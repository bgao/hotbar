angular.module('hotbar.controllers', [])

.controller('MediaCtrl', function($scope, $ionicLoading, $log, Media) {
    $ionicLoading.show({
        template: 'Loading...'
    });
    Media.all(function(err, media) {
        if (err) {
            $log.error(err);
            $scope.media = [];
        } else {
            $scope.media = media;
            var access_token = "W_YxUsgeUvwAAAAAAAACaVjEraJtDmHnS3_s2ilMCX3jEABkDWp6H0Vg75w7AaBh";
            var dropbox_base = "https://api-content.dropbox.com/1/";
            $scope.asset=dropbox_base+"thumbnails/sandbox/test.jpg?size=m&access_token="+
                access_token;
            $ionicLoading.hide();
            // console.log(media[0]);
            // Media.getAsset(media[0], function(err, data) {
            //     if (err) {
            //         $log.error(err);
            //     } else {
            //         // console.log(data);
            //         if (!$scope.$$phase) {
            //             $scope.$apply(function() {
            //                 $scope.asset = btoa(encodeURIComponent(data));
            //             });
            //         } else {
            //             $scope.asset = "data:image/jpeg;base64,"+window.btoa(data);
            //             $log.info($scope.asset);
            //         }
            //     }
            //     $ionicLoading.hide();
            // });
        }
        // $scope.$apply();
        // $ionicLoading.hide();
    });
})

.controller('MediaDetailCtrl', function($scope, $stateParams, $log, Media) {
    $ionicLoading.show({
        template: 'Loading...'
    });
    Media.get($stateParams.mediaId, function(err, media) {
        var _media = null;
        if (err) {
            $log.error(err);
        } else {
            _media = media;
        }
        $scope.$apply(function(){ $scope.media = _media; });
        $ionicLoading.hide();
    });
})

.controller('CameraCtrl', function($scope, $log, Media) {
    var navigator = window.navigator;
    var captureSuccess = function(mediaFiles) {
        $log.info(mediaFile[0].fullPath);
    }
    var captureError = function(error) {
        navigator.notification.alert('Error code: ' + error.code, null,
                                     'Capture Error');
    }
    function captureImage() {
        window.navigator.device.capture.captureImage(captureSuccess,
                                                     captureError);
    }
    function captureVideo() {
        window.navigator.device.capture.captureVideo(captureSuccess,
                                                     captureError,
                                                     { duration: 20 });
    }
})

.controller('BarsCtrl', function($scope, $ionicLoading, $log, Bars, Global) {
    var _infowindow = new google.maps.InfoWindow();
    var _map;

    function callback(results, status) {
        $scope.$apply(function(){
            $scope.bars = results;
        });
        if (status == google.maps.places.PlacesServiceStatus.OK) {
            for (var i = 0; i < results.length; i++) {
                createMarker(results[i]);
            }
        }
        $ionicLoading.hide();
    }
    
    function createMarker(place) {
        var placeLoc = place.geometry.location;
        var marker = new google.maps.Marker({
            map: _map,
            position: place.geometry.location
        });
        
        google.maps.event.addListener(marker, 'click', function() {
            _infowindow.setContent(place.name);
            _infowindow.open(_map, this);
        });
    }

    function findBars(map) {
        _map = map;
        var request = {
            location: Global.position,
            radius: Global.radius,
            types: ['bar']
        };
        var service = new google.maps.places.PlacesService(map);
        service.nearbySearch(request, callback);
    };
    $scope.map = {
        center: {
            latitude: Global.position.lat(),
            longitude: Global.position.lng()
        },
        zoom: 12,
        events: {
            tilesloaded: function (map) {
                findBars(map);
                $scope.$apply(function () {
                    $log.info('this is the map instance', map);				
                });
            }
        }
    };

    $ionicLoading.show({
        template: "Loading..."
    });

    /* Bars.all(function(err, bars) {
        var _bars = [];
        if (err) {
            $log.error(err);
        } else {
            _bars = bars;
        }
        $scope.$apply(function(){ $scope.bars = _bars; });
        $ionicLoading.hide();
    }); */
})

.controller('BarDetailCtrl', function($scope, $stateParams, $log, Bars) {
    $ionicLoading.show({
        template: 'Loading...'
    });
    Bars.get($stateParams.mediaId, function(err, bar) {
        var _bar = null;
        if (err) {
            $log.error(err);
        } else {
            _bar = bar;
        }
        $scope.$apply(function(){ $scope.bar = _bar; });
        $ionicLoading.hide();
    });
})

.controller('AccountCtrl', function($scope, $ionicLoading, Global) {
    var user = Global.user;
    var client = Global.client;
    if (user) {
        $ionicLoading.show({
            template: "Loading..."
        });
        client.getFeedForUser(user._data.username, function(err, data, entities) {
            $scope.data = entities;
            $scope.$apply();
            $ionicLoading.hide();
        });
    }
})

.controller('LoginCtrl', function($scope, $ionicLoading, $state, $log, Users) {
    console.log(window.localStorage);
    if (window.localStorage["apigee_token"]) $state.go('tab.media');

    $scope.loggedIn = false;
    $scope.logout = function() {
        Users.logout();
        $scope.loggedIn = false;
    };
    $scope.login = function(user) {
        var username = user.username;
        var password = user.password;
        $ionicLoading.show({
            template: "Loading..."
        });
        if (username && password) {
            Users.login(username, password, function(err, user) {
                if (err) {
                    $log.error(err);
                } else {
                    if (user) $scope.loggedIn = true;
                    $scope.$apply();
                    $ionicLoading.hide();
                    $state.go('tab.media');
                }
            });
        }
    };
    $scope.signup = function() {
        $state.go('signup');
    };
})
.controller('SignupCtrl', function($scope, $ionicLoading, $state, Users) {
    $scope.signup = function(user) {
        var username = user.username;
        var password = user.password;
        var email = user.email;
        var name = user.name;
        $ionicLoading.show({
            template: "Loading..."
        });
        if (username && password && email) {
            Users.signup(username, password, email, name, function(err, user) {
                if (err) {
                    $log.error(err);
                } else {
                    $state.go('tab.media');
                }
                $ionicLoading.hide();
            });
        } else {
            $ionicLoading.hide();
        }
    }
});
