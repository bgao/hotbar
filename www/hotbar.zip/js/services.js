angular.module('hotbar.services', [])
.factory('Global', [function() {
    var _this = this;
    // _this._data = {
    //     client: window.client,
    //     user: window.user,
    //     authenticated: !!window.user
    // };
    if (!_this._data) 
        _this._data = {
            client: window.client, // window.localStorage['client'],
            user: window.user, // window.localStorage['user'],
            position: window.position, // window.localStorage['position']
            radius: window.radius
        };
    if (!_this._data.client) {
        var client_creds = {  // TODO: needs to be abstracted
            orgName: "hotbar",
            appName: "hotbar",
            logging: true
        };
        _this._data.client = new window.Apigee.Client(client_creds);
        window.client = _this._data.client;
    }
    if (!_this._data.position) {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(pos) {
                _this._data.position =
                    new google.maps.LatLng(pos.coords.latitude,
                                           pos.coords.longitude);
            });
        } else {
            _this._data.position =
                new google.maps.LatLng(42.358431, -71.059773); // Boston
        }
        window.position = _this._data.position;
    }
    if (!_this._data.radius) {
        _this._data.radius = 5*1.6*1000; // 5 miles = 8000 meters
        window.radius = _this._data.radius;
    }
    return _this._data;
}])
.factory('Bars', ['Global', function(Global) {
    var client = Global.client;
    var options = {
        method: 'GET',
        endpoint: 'bars'
    };
    return {
        all: function(callback) {
            client.request(options, function(err, data) { // TODO: abstraction
                if (err) {
                    callback(err, null);
                } else {
                    callback(null, data.entities);
                }
            });
        },
        get: function(barId, callback) {
            callback(null,null);
        }
    }
}])
.factory('Media', ['$window', '$http', '$log', 'Global', function($window, $http, $log, Global) {
    var client = Global.client;
    var options = {
        method: 'GET',
        endpoint: 'media'
    };
    var access_token = "W_YxUsgeUvwAAAAAAAACaVjEraJtDmHnS3_s2ilMCX3jEABkDWp6H0Vg75w7AaBh";
    var dropbox_base = "https://api-content.dropbox.com/1/";
    return {
        all: function(callback) {
            client.request(options, function(err, data) {  // TODO: abstraction
                if (err) {
                    callback(err, null);
                } else {
                    callback(null, data.entities);
                }
            });
        },
        get: function(mediaId, callback) {
            callback(null,null);
        },
        getAsset: function(media, callback) {
            var url = dropbox_base + "thumbnails/sandbox/test.jpg?access_token=" +
                access_token;
            $http.get(url)
                .success(function(data, status) {
                    $log.info('success: ' + status);
                    callback(null, data);
                })
                .error(function(data, status) {
                    $log.error('error: ' + status);
                    callback(status, null);
                });
            // var header = media['file-metadata']['content-type'];
            // var url = "https://api.usergrid.com/hotbar/hotbar/media/"+
            //     media.uuid+"?access_token="+$window.localStorage.apigee_token;
            // $http.get(url, {headers:{'Accept': header}})
            //     .success(function(data, status){
            //         console.log('Type ' + typeof(data));
            //         console.log('success: ' + status);
            //         callback(null, data);
            //     })
            //     .error(function(data, status) {
            //         console.log('error: ' + status);
            //         callback(status, null);
            //     });
        },
        upload: function(media, callback) {
            var _url = dropbox_base + "put_files/sandbox/" + Global.user.username+
                media.filename;
            $http.post(_url+"?access_token="+access_token, media.data)
                .success(function(data, status) {
                    // create apigee media entity
                    var options = {
                        type: 'media',
                        caption: media.caption,
                        url: _url
                    };
                    client.createEntity(options, function(err, media, data) {
                        if (err) {
                            $log.error('error: ' + err);
                            callback(err, null);
                        } else {
                            callback(null, media);
                        }
                    });
                })
                .error(function(data, status) {
                    $log.error('error: ' + status);
                    callback(status, null);
                });
        }
    }
}])
.factory('Users', ['Global', function(Global) {
    var client = Global.client;
    return {
        login: function(username, password, callback) {
            client.login(username, password, function(err) {
                if (err) {
                    callback(err, null);
                } else {
                    client.getLoggedInUser(function(err, data, user) {
                        if (err) {
                            callback(err, null);
                        } else {
                            if (client.isLoggedIn()) {
                                Global.user = user;
                                window.user = Global.user;
                                callback(null, user);
                            } else {
                                Global.user = null;
                                callback(null, null);
                            }
                        }
                    });
                }
            });
        },
        logout: function() {
            client.logout();
        },
        signup: function(username, password, email, name, callback) {
            client.signup(username, password, email, name, function (err, user) {
                if (err) {
                    callback(err, null);
                } else {
                    Global.user = user;
                    window.user = user;
                    callback(null, user);
                }
            });
        }
    }
}]);
